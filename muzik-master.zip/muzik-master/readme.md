# Muzik! – Music streaming website
## Description

Muzik! is a web app similar to Spotify that lets you listen to a huge library of songs in streaming.

This school project aims at teaching us the complete website making process, from the initial idea, to the discovery of competitors and the target audience, to the design and development of the site.

Due to the limited time for development, the product is just a concept/prototype and is missing a lot of pages and contents.

## License
[MIT](LICENSE)